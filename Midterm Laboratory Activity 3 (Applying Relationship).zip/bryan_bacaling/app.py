from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)


app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:1234@localhost/bryanpeter_db'
app.config['SQLALCHEMY_BINDS'] = {'logs': 'sqlite:///attendance_logs.db'}
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


db = SQLAlchemy(app)


class Record(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(255), nullable=False)


class Log(db.Model):
    __bind_key__ = 'logs'  
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)


with app.app_context():
    db.create_all()


@app.route('/')
def index():
    records = Record.query.all()
    return render_template('index.html', records=records)


@app.route('/view-logs')
def logs_page():
    logs = Log.query.all()
    return render_template('logs.html', logs=logs)


@app.route('/create', methods=['POST'])
def create_record():
    data = request.json
    new_record = Record(name=data['name'], description=data['description'])
    db.session.add(new_record)
    db.session.commit()

    log_action("Created record")
    return jsonify({'message': 'Record created successfully'})


@app.route('/read', methods=['GET'])
def read_records():
    records = Record.query.all()
    return jsonify([{'id': r.id, 'name': r.name, 'description': r.description} for r in records])


@app.route('/update/<int:id>', methods=['PUT'])
def update_record(id):
    record = Record.query.get(id)
    if not record:
        return jsonify({'message': 'Record not found'}), 404

    data = request.json
    record.name = data['name']
    record.description = data['description']
    db.session.commit()

    log_action("Updated record")
    return jsonify({'message': 'Record updated successfully'})


@app.route('/delete/<int:id>', methods=['DELETE'])
def delete_record(id):
    record = Record.query.get(id)
    if not record:
        return jsonify({'message': 'Record not found'}), 404

    db.session.delete(record)
    db.session.commit()

    log_action("Deleted record")
    return jsonify({'message': 'Record deleted successfully'})

@app.route('/logs', methods=['GET'])
def get_logs():
    logs = Log.query.all()
    return jsonify([{'id': log.id, 'action': log.action, 'timestamp': log.timestamp} for log in logs])


def log_action(action):
    log_entry = Log(action=action)
    db.session.add(log_entry)  
    db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)
